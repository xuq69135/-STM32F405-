#ifndef __PWM_H__
#define __PWM_H__

void PWM_Configuration(void);
void motor_control_L(int direction ,int value0 );
void motor_control_R(int direction ,int value0 );
#endif
