#ifndef __ENCODER_H__
#define __ENCODER_H__

void Encoder_Configuration1(void);
void Encoder_Start1(void);
int Encoder_Get_CNT1(void);

void Encoder_Configuration2(void);
void Encoder_Start2(void);
int Encoder_Get_CNT2(void);


#endif



